using ApexPost.Domain.Enums;
using ApexPost.Domain.ValueObjects;

namespace ApexPost.Domain.Entities;

public sealed record CounterTransaction
{
    public Guid Id { get; }
    public string TransactionNumber { get; }
    public Guid BranchId { get; }
    public Guid StaffId { get; }
    public Guid? TerminalId { get; }
    public Guid? MoneyOrderId { get; }
    public decimal MoneyOrderAmount { get; }
    public decimal MoneyOrderFee { get; }
    public DateTimeOffset OccurredAt { get; }
    public IReadOnlyList<TransactionLine> Lines { get; }
    public Guid? ShippingRateId { get; }
    public string? ShippingZoneName { get; }
    public ShippingServiceLevel? ShippingServiceLevel { get; }
    public ShipmentType? ShipmentType { get; }
    public decimal? ShippingWeightKilograms { get; }
    public decimal Subtotal { get; }
    public decimal TaxTotal { get; }
    public decimal ShippingCharge { get; }
    public decimal ShippingTaxRatePercent { get; }
    public decimal ShippingTaxAmount { get; }
    public decimal TotalAmount { get; }
    public PaymentMethod PaymentMethod { get; }
    public TransactionStatus Status { get; }
    public DateTimeOffset? ResolvedAt { get; }
    public Guid? ResolvedByStaffId { get; }
    public string? ResolutionReason { get; }
    public string? ShippingRecipientName { get; }
    public string? ShippingAddress { get; }
    public decimal? ParcelLengthCentimeters { get; }
    public decimal? ParcelWidthCentimeters { get; }
    public decimal? ParcelHeightCentimeters { get; }

    public CounterTransaction(
        Guid id,
        string transactionNumber,
        Guid branchId,
        Guid staffId,
        DateTimeOffset occurredAt,
        IReadOnlyList<TransactionLine> lines,
        Guid? shippingRateId,
        string? shippingZoneName,
        ShippingServiceLevel? shippingServiceLevel,
        decimal? shippingWeightKilograms,
        decimal shippingCharge,
        PaymentMethod paymentMethod,
        TransactionStatus status = TransactionStatus.Paid,
        DateTimeOffset? resolvedAt = null,
        Guid? resolvedByStaffId = null,
        string? resolutionReason = null,
        string? shippingRecipientName = null,
        string? shippingAddress = null,
        decimal? parcelLengthCentimeters = null,
        decimal? parcelWidthCentimeters = null,
        decimal? parcelHeightCentimeters = null,
        decimal shippingTaxRatePercent = 0m,
        Guid? terminalId = null,
        Guid? moneyOrderId = null,
        decimal moneyOrderAmount = 0m,
        decimal moneyOrderFee = 0m,
        ShipmentType? shipmentType = null)
    {
        if (id == Guid.Empty || branchId == Guid.Empty || staffId == Guid.Empty)
        {
            throw new ArgumentException("Transaction, branch, and staff identifiers are required.");
        }

        ArgumentException.ThrowIfNullOrWhiteSpace(transactionNumber);
        ArgumentNullException.ThrowIfNull(lines);
        if (!Enum.IsDefined(paymentMethod))
        {
            throw new ArgumentOutOfRangeException(nameof(paymentMethod));
        }

        if (!Enum.IsDefined(status))
        {
            throw new ArgumentOutOfRangeException(nameof(status));
        }

        if (status is (TransactionStatus.Open or TransactionStatus.Paid or TransactionStatus.Completed) &&
            (resolvedAt is not null || resolvedByStaffId is not null || resolutionReason is not null))
        {
            throw new ArgumentException("Open and paid transactions cannot contain reversal details.", nameof(status));
        }

        if (status is (TransactionStatus.Voided or TransactionStatus.Refunded) &&
            (resolvedAt is null || resolvedByStaffId is null || resolvedByStaffId == Guid.Empty || string.IsNullOrWhiteSpace(resolutionReason)))
        {
            throw new ArgumentException("A void or refund requires an actor, time, and reason.", nameof(status));
        }

        if (lines.Count == 0 && shippingRateId is null && moneyOrderId is null)
        {
            throw new ArgumentException("A transaction must contain a product, shipping service, or money order.", nameof(lines));
        }

        if (moneyOrderId is null && (moneyOrderAmount != 0 || moneyOrderFee != 0))
            throw new ArgumentException("Money order amounts require a linked money order.", nameof(moneyOrderId));
        if (moneyOrderId is not null && (moneyOrderAmount <= 0 || moneyOrderFee < 0 ||
            decimal.Round(moneyOrderAmount, 2) != moneyOrderAmount || decimal.Round(moneyOrderFee, 2) != moneyOrderFee))
            throw new ArgumentOutOfRangeException(nameof(moneyOrderAmount), "Money order amount and fee must be valid currency amounts.");

        if (shippingRateId is null &&
            (shippingZoneName is not null || shippingServiceLevel is not null || shippingWeightKilograms is not null || shippingCharge != 0 || shipmentType is not null))
        {
            throw new ArgumentException("Shipping details require a shipping rate.", nameof(shippingRateId));
        }

        if (shippingRateId is not null &&
            (string.IsNullOrWhiteSpace(shippingZoneName) || shippingServiceLevel is null || shippingWeightKilograms is null || shippingWeightKilograms <= 0))
        {
            throw new ArgumentException("Complete shipping details are required when a rate is selected.", nameof(shippingRateId));
        }

        if (shipmentType is { } selectedShipmentType && !Enum.IsDefined(selectedShipmentType))
            throw new ArgumentOutOfRangeException(nameof(shipmentType));

        var hasAddressDetails = shippingRecipientName is not null || shippingAddress is not null ||
            parcelLengthCentimeters is not null || parcelWidthCentimeters is not null || parcelHeightCentimeters is not null;
        if (hasAddressDetails &&
            (shippingRateId is null || string.IsNullOrWhiteSpace(shippingRecipientName) ||
             string.IsNullOrWhiteSpace(shippingAddress) ||
             (shipmentType != ApexPost.Domain.Enums.ShipmentType.Letter &&
              (parcelLengthCentimeters is null || parcelWidthCentimeters is null || parcelHeightCentimeters is null))))
        {
            throw new ArgumentException("Recipient and destination address are required; parcels also require all dimensions.");
        }

        if (shipmentType == ApexPost.Domain.Enums.ShipmentType.Letter &&
            (parcelLengthCentimeters is not null || parcelWidthCentimeters is not null || parcelHeightCentimeters is not null))
            throw new ArgumentException("Letter shipments do not have parcel dimensions.", nameof(shipmentType));

        if (shipmentType is not null && !hasAddressDetails)
            throw new ArgumentException("Shipment recipient and address details are required.", nameof(shippingRecipientName));

        if (shippingRecipientName?.Trim().Length > 100 || shippingAddress?.Trim().Length > 300)
        {
            throw new ArgumentException("Recipient name and destination address exceed their maximum lengths.");
        }

        foreach (var dimension in new[] { parcelLengthCentimeters, parcelWidthCentimeters, parcelHeightCentimeters })
        {
            if (dimension is { } value && (value <= 0 || decimal.Round(value, 2) != value))
            {
                throw new ArgumentOutOfRangeException(nameof(parcelLengthCentimeters), "Parcel dimensions must be positive and use no more than two decimal places.");
            }
        }

        if (shippingCharge < 0 || decimal.Round(shippingCharge, 2) != shippingCharge)
        {
            throw new ArgumentOutOfRangeException(nameof(shippingCharge));
        }

        if (shippingTaxRatePercent < 0 || shippingTaxRatePercent > 100 || decimal.Round(shippingTaxRatePercent, 2) != shippingTaxRatePercent)
        {
            throw new ArgumentOutOfRangeException(nameof(shippingTaxRatePercent));
        }

        Id = id;
        TransactionNumber = transactionNumber.Trim();
        BranchId = branchId;
        StaffId = staffId;
        TerminalId = terminalId;
        MoneyOrderId = moneyOrderId;
        MoneyOrderAmount = moneyOrderAmount;
        MoneyOrderFee = moneyOrderFee;
        OccurredAt = occurredAt;
        Lines = lines.ToArray();
        ShippingRateId = shippingRateId;
        ShippingZoneName = shippingZoneName;
        ShippingServiceLevel = shippingServiceLevel;
        ShipmentType = shipmentType;
        ShippingWeightKilograms = shippingWeightKilograms;
        Subtotal = Money.Sum(Lines.Select(line => new Money(line.LineTotal))).Amount;
        TaxTotal = Money.Sum(Lines.Select(line => new Money(line.TaxAmount))).Amount;
        ShippingCharge = shippingCharge;
        ShippingTaxRatePercent = shippingTaxRatePercent;
        ShippingTaxAmount = new Money(ShippingCharge).Percentage(shippingTaxRatePercent).Amount;
        TaxTotal = Money.Sum([new Money(TaxTotal), new Money(ShippingTaxAmount)]).Amount;
        TotalAmount = Money.Sum([
            new Money(Subtotal), new Money(TaxTotal), new Money(ShippingCharge),
            new Money(MoneyOrderAmount), new Money(MoneyOrderFee)
        ]).Amount;
        PaymentMethod = paymentMethod;
        Status = status;
        ResolvedAt = resolvedAt;
        ResolvedByStaffId = resolvedByStaffId;
        ResolutionReason = resolutionReason?.Trim();
        ShippingRecipientName = shippingRecipientName?.Trim();
        ShippingAddress = shippingAddress?.Trim();
        ParcelLengthCentimeters = parcelLengthCentimeters;
        ParcelWidthCentimeters = parcelWidthCentimeters;
        ParcelHeightCentimeters = parcelHeightCentimeters;
    }

    public CounterTransaction Void(Guid managerId, string reason, DateTimeOffset occurredAt) =>
        Resolve(TransactionStatus.Voided, managerId, reason, occurredAt);

    public CounterTransaction Refund(Guid managerId, string reason, DateTimeOffset occurredAt) =>
        Resolve(TransactionStatus.Refunded, managerId, reason, occurredAt);

    private CounterTransaction Resolve(TransactionStatus status, Guid managerId, string reason, DateTimeOffset occurredAt)
    {
        if (Status is not (TransactionStatus.Paid or TransactionStatus.Completed))
        {
            throw new InvalidOperationException("Only a paid transaction can be voided or refunded.");
        }

        if (managerId == Guid.Empty)
        {
            throw new ArgumentException("The manager performing the reversal is required.", nameof(managerId));
        }

        ArgumentException.ThrowIfNullOrWhiteSpace(reason);
        if (reason.Trim().Length > 250)
        {
            throw new ArgumentException("The reason cannot exceed 250 characters.", nameof(reason));
        }

        return new CounterTransaction(
            Id, TransactionNumber, BranchId, StaffId, OccurredAt, Lines, ShippingRateId,
            ShippingZoneName, ShippingServiceLevel, ShippingWeightKilograms, ShippingCharge,
            PaymentMethod, status, occurredAt, managerId, reason, ShippingRecipientName,
            ShippingAddress, ParcelLengthCentimeters, ParcelWidthCentimeters, ParcelHeightCentimeters,
            ShippingTaxRatePercent, TerminalId, MoneyOrderId, MoneyOrderAmount, MoneyOrderFee, ShipmentType);
    }
}
