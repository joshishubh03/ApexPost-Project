using System.Net;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text.Encodings.Web;
using ApexPost.Application.Abstractions;
using ApexPost.Application.Models;
using ApexPost.Domain.Entities;
using ApexPost.Domain.Enums;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

var tempDir = Path.Combine(Path.GetTempPath(), $"apexpost-probe-{Guid.NewGuid():N}");
using var factory = new WebApplicationFactory<Program>().WithWebHostBuilder(builder =>
{
    builder.UseEnvironment("Testing");
    builder.UseSetting("Persistence:Provider", "Json");
    builder.UseSetting("ApexPost:DataDirectory", tempDir);
    builder.ConfigureAppConfiguration((_, configuration) =>
    {
        var testSettings = new Dictionary<string, string?>
        {
            ["Persistence:Provider"] = "Json",
            ["ApexPost:DataDirectory"] = tempDir,
            ["PartnerApi:ApiKey"] = "integration-test-key",
            ["PartnerApi:AllowedCorsOrigins:0"] = "https://widget.example",
            ["Security:MaintenanceMode"] = "false",
            ["Security:AdminAllowedIpAddresses:0"] = "192.0.2.10",
            ["Security:IntegrationAllowedIpAddresses:0"] = "192.0.2.10",
            ["Security:IntegrationAllowedIpAddresses:1"] = "192.0.2.11"
        };
        configuration.AddInMemoryCollection(testSettings);
    });
    builder.ConfigureTestServices(services =>
    {
        services.PostConfigure<ForwardedHeadersOptions>(options =>
        {
            options.KnownIPNetworks.Clear();
            options.KnownProxies.Clear();
            options.KnownProxies.Add(IPAddress.Loopback);
            options.KnownProxies.Add(IPAddress.IPv6Loopback);
        });
        services.AddSingleton<IStartupFilter, TestStartupFilter>();
        services.RemoveAll<ApexPost.Application.Abstractions.IAuthenticationService>();
        services.AddSingleton<ApexPost.Application.Abstractions.IAuthenticationService, TestAuthService>();
        services.AddDataProtection().UseEphemeralDataProtectionProvider();
        services.RemoveAll<ICounterTransactionRepository>();
        services.AddSingleton<ICounterTransactionRepository, FakeCounterTransactionRepository>();
        services.AddAuthentication(options => options.DefaultAuthenticateScheme = "IntegrationTest")
            .AddScheme<AuthenticationSchemeOptions, TestAuthenticationHandler>("IntegrationTest", _ => { });
    });
});

var client = factory.CreateClient(new WebApplicationFactoryClientOptions
{
    BaseAddress = new Uri("https://localhost"),
    HandleCookies = true,
    AllowAutoRedirect = false
});
client.DefaultRequestHeaders.Add("X-Test-Role", nameof(StaffRole.Administrator));
var request = new HttpRequestMessage(HttpMethod.Get, "/Administration/Branches");
request.Headers.Add("X-Forwarded-For", "192.0.2.10");
var response = await client.SendAsync(request);
Console.WriteLine($"Status: {(int)response.StatusCode} {response.StatusCode}");
Console.WriteLine(await response.Content.ReadAsStringAsync());

var request2 = new HttpRequestMessage(HttpMethod.Get, "/Reports/AuditOverview");
request2.Headers.Add("X-Test-Role", nameof(StaffRole.Auditor));
request2.Headers.Add("X-Forwarded-For", "192.0.2.10");
var response2 = await client.SendAsync(request2);
Console.WriteLine($"Status2: {(int)response2.StatusCode} {response2.StatusCode}");
Console.WriteLine(await response2.Content.ReadAsStringAsync());

sealed class TestAuthService : ApexPost.Application.Abstractions.IAuthenticationService
{
    public Task<StaffSession?> AuthenticateAsync(string email, string password, CancellationToken cancellationToken = default)
        => Task.FromResult<StaffSession?>(new StaffSession(
            Guid.Parse("10000000-0000-0000-0000-000000000001"),
            email,
            "Integration Clerk",
            StaffRole.CounterClerk,
            Guid.Parse("20000000-0000-0000-0000-000000000001"),
            "AP-001",
            "Integration Branch"));
}

sealed class TestStartupFilter : IStartupFilter
{
    public Action<IApplicationBuilder> Configure(Action<IApplicationBuilder> next) => app =>
    {
        app.Use(async (context, nextMiddleware) =>
        {
            context.Connection.RemoteIpAddress = IPAddress.Loopback;
            await nextMiddleware();
        });
        next(app);
    };
}

sealed class TestAuthenticationHandler(IOptionsMonitor<AuthenticationSchemeOptions> options, ILoggerFactory logger, UrlEncoder encoder) : AuthenticationHandler<AuthenticationSchemeOptions>(options, logger, encoder)
{
    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        if (!Enum.TryParse<StaffRole>(Request.Headers["X-Test-Role"], out var role))
        {
            return Task.FromResult(AuthenticateResult.NoResult());
        }

        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, "10000000-0000-0000-0000-000000000001"),
            new Claim(ClaimTypes.Name, "Integration Test User"),
            new Claim(ClaimTypes.Role, role.ToString()),
            new Claim("branch_id", "20000000-0000-0000-0000-000000000001")
        };
        var principal = new ClaimsPrincipal(new ClaimsIdentity(claims, Scheme.Name));
        return Task.FromResult(AuthenticateResult.Success(new AuthenticationTicket(principal, Scheme.Name)));
    }
}

sealed class FakeCounterTransactionRepository : ICounterTransactionRepository
{
    public Task<IReadOnlyList<CounterTransaction>> GetAllAsync(CancellationToken cancellationToken = default) =>
        Task.FromResult<IReadOnlyList<CounterTransaction>>(new[]
        {
            CreateShipment(Guid.Parse("30000000-0000-0000-0000-000000000001"), Guid.Parse("20000000-0000-0000-0000-000000000001"), "APT-20261025-LABEL001")
        });

    public Task SaveAllAsync(IEnumerable<CounterTransaction> transactions, CancellationToken cancellationToken = default) => Task.CompletedTask;

    private static CounterTransaction CreateShipment(Guid id, Guid branchId, string number) => new(
        id,
        number,
        branchId,
        Guid.Parse("10000000-0000-0000-0000-000000000001"),
        DateTimeOffset.UtcNow,
        [],
        Guid.NewGuid(),
        "Local Metro",
        ShippingServiceLevel.Standard,
        1m,
        25m,
        PaymentMethod.Cash,
        shippingRecipientName: "Test Recipient",
        shippingAddress: "1 Main Street, Central",
        parcelLengthCentimeters: 20m,
        parcelWidthCentimeters: 15m,
        parcelHeightCentimeters: 10m);
}
