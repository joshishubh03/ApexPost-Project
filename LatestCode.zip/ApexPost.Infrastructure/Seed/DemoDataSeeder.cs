using ApexPost.Application.Abstractions;
using ApexPost.Application.Models;
using ApexPost.Domain.Entities;
using ApexPost.Domain.Enums;

namespace ApexPost.Infrastructure.Seed;

public sealed class DemoDataSeeder(
    IBranchRepository branchRepository,
    IStaffRepository staffRepository,
    IProductRepository productRepository,
    IInventoryRepository inventoryRepository,
    ICounterTransactionRepository transactionRepository,
    IMoneyOrderRepository moneyOrderRepository,
    IIdentityVerificationRepository verificationRepository,
    IShippingZoneRepository shippingZoneRepository,
    IShippingRateRepository shippingRateRepository,
    ICounterTerminalRepository terminalRepository,
    IStaffPasswordService passwordService,
    MoneyOrderPolicy moneyOrderPolicy,
    string demoPassword,
    IApplicationMutationCoordinator mutationCoordinator)
{
    public Task SeedAsync(CancellationToken cancellationToken = default) =>
        mutationCoordinator.RunAsync(() => SeedCoreAsync(cancellationToken), cancellationToken);

    private async Task SeedCoreAsync(CancellationToken cancellationToken)
    {
        var branches = await branchRepository.GetAllAsync(cancellationToken);
        if (branches.Count == 0)
        {
            branches = Enumerable.Range(1, 5)
                .Select(index => new Branch(
                    Guid.Parse($"10000000-0000-0000-0000-{index:000000000000}"),
                    $"AP-{index:000}",
                    $"ApexPost Branch {index}",
                    $"Region {index}",
                    isOpen: true))
                .ToArray();
            await branchRepository.SaveAllAsync(branches, cancellationToken);
        }

        var terminals = await terminalRepository.GetAllAsync(cancellationToken);
        if (terminals.Count == 0)
        {
            terminals = branches.SelectMany(branch => Enumerable.Range(1, 2).Select(number => new CounterTerminal(
                StableGuid($"terminal-{branch.Code}-{number}"), branch.Id, $"T-{number:00}", $"Counter {number}"))).ToArray();
            await terminalRepository.SaveAllAsync(terminals, cancellationToken);
        }

        var products = await productRepository.GetAllAsync(cancellationToken);
        if (products.Count == 0)
        {
            var productSeeds = new (string Sku, string Name, string Description, string Category, decimal Price)[]
            {
                ("POST-001", "Domestic Letter", "Standard domestic letter postage", "Postage", 25.00m),
                ("POST-002", "Large Letter", "Large format domestic letter postage", "Postage", 45.00m),
                ("POST-003", "Registered Letter", "Tracked registered letter service", "Postage", 85.00m),
                ("POST-004", "Express Letter", "Priority domestic letter service", "Postage", 120.00m),
                ("POST-005", "Postcard", "Domestic postcard postage", "Postage", 15.00m),
                ("POST-006", "International Letter", "Standard international letter postage", "Postage", 150.00m),
                ("POST-007", "International Express", "Priority international letter service", "Postage", 450.00m),
                ("POST-008", "Printed Matter", "Printed material postal service", "Postage", 35.00m),
                ("PACK-001", "Small Mailing Box", "Small corrugated mailing box", "Packaging", 40.00m),
                ("PACK-002", "Medium Mailing Box", "Medium corrugated mailing box", "Packaging", 65.00m),
                ("PACK-003", "Large Mailing Box", "Large corrugated mailing box", "Packaging", 95.00m),
                ("PACK-004", "Document Envelope", "Rigid document mailing envelope", "Packaging", 20.00m),
                ("PACK-005", "Padded Mailer", "Protective padded mailer", "Packaging", 30.00m),
                ("PACK-006", "Bubble Wrap Roll", "Protective bubble wrap roll", "Packaging", 110.00m),
                ("PACK-007", "Packing Tape", "Standard clear packing tape", "Packaging", 35.00m),
                ("PACK-008", "Shipping Labels", "Pack of adhesive shipping labels", "Packaging", 55.00m),
                ("RETL-001", "ApexPost Pen", "Branded blue ballpoint pen", "Stationery", 20.00m),
                ("RETL-002", "ApexPost Notebook", "Branded pocket notebook", "Stationery", 60.00m),
                ("RETL-003", "Address Book", "Hardcover address book", "Stationery", 125.00m),
                ("RETL-004", "Greeting Card", "Blank all-occasion greeting card", "Stationery", 40.00m),
                ("RETL-005", "Gift Wrap Sheet", "Decorative gift wrapping sheet", "Packaging", 25.00m),
                ("RETL-006", "Postage Stamp Sheet", "Sheet of domestic postage stamps", "Postage", 100.00m),
                ("RETL-007", "Desk Calendar", "ApexPost annual desk calendar", "Office Supplies", 85.00m),
                ("RETL-008", "Document Folder", "Reusable document folder", "Office Supplies", 45.00m),
                ("SHIP-001", "Small Parcel Service", "Domestic small parcel handling", "Shipping", 90.00m),
                ("SHIP-002", "Medium Parcel Service", "Domestic medium parcel handling", "Shipping", 160.00m),
                ("SHIP-003", "Large Parcel Service", "Domestic large parcel handling", "Shipping", 280.00m),
                ("SHIP-004", "Fragile Handling", "Additional fragile parcel handling", "Shipping", 75.00m),
                ("MORD-001", "Money Order Fee - Basic", "Basic money order processing fee", "Money Order", 30.00m),
                ("MORD-002", "Money Order Fee - Express", "Express money order processing fee", "Money Order", 65.00m)
            };
            var seededProducts = productSeeds.Select((seed, index) => new Product(
                Guid.Parse($"20000000-0000-0000-0000-{index + 1:000000000000}"),
                seed.Sku, seed.Name, seed.Description, seed.Category, seed.Price, isActive: true)).ToArray();
            await productRepository.SaveAllAsync(seededProducts, cancellationToken);
            products = seededProducts;
        }

        var zones = await shippingZoneRepository.GetAllAsync(cancellationToken);
        if (zones.Count == 0)
        {
            var zoneSeeds = new (string Code, string Name, string Destination)[]
            {
                ("DOM-LOCAL", "Local Metro", "Same city or metropolitan area"),
                ("DOM-STATE", "Intra-State", "Destinations within the same state"),
                ("DOM-NORTH", "North Zone", "Northern India"),
                ("DOM-SOUTH", "South Zone", "Southern India"),
                ("DOM-EAST", "East Zone", "Eastern India"),
                ("DOM-WEST", "West Zone", "Western India"),
                ("DOM-CENTRAL", "Central Zone", "Central India"),
                ("DOM-NE", "North-East Zone", "North-Eastern India"),
                ("DOM-REMOTE", "Remote Areas", "Remote and difficult-to-reach areas"),
                ("INT-REG", "International Regional", "International destinations")
            };
            zones = zoneSeeds.Select((seed, index) => new ShippingZone(
                Guid.Parse($"30000000-0000-0000-0000-{index + 1:000000000000}"),
                seed.Code, seed.Name, seed.Destination, isActive: true)).ToArray();
            await shippingZoneRepository.SaveAllAsync(zones, cancellationToken);
        }

        var rates = await shippingRateRepository.GetAllAsync(cancellationToken);
        if (rates.Count == 0)
        {
            var seededRates = zones.SelectMany((zone, index) => new[]
            {
                new ShippingRate(
                    Guid.Parse($"40000000-0000-0000-0000-{index + 1:000000000000}"),
                    zone.Id,
                    ShippingServiceLevel.Standard,
                    35m + index * 5m,
                    12m + index * 2m,
                    30m,
                    isActive: true),
                new ShippingRate(
                    Guid.Parse($"50000000-0000-0000-0000-{index + 1:000000000000}"),
                    zone.Id,
                    ShippingServiceLevel.Express,
                    65m + index * 7m,
                    22m + index * 3m,
                    30m,
                    isActive: true)
            });
            await shippingRateRepository.SaveAllAsync(seededRates, cancellationToken);
            rates = seededRates.ToArray();
        }

        var seededZoneIndices = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase)
        {
            ["DOM-LOCAL"] = 0,
            ["DOM-STATE"] = 1,
            ["DOM-NORTH"] = 2,
            ["DOM-SOUTH"] = 3,
            ["DOM-EAST"] = 4,
            ["DOM-WEST"] = 5,
            ["DOM-CENTRAL"] = 6,
            ["DOM-NE"] = 7,
            ["DOM-REMOTE"] = 8,
            ["INT-REG"] = 9
        };
        var missingRegisteredRates = zones
            .Where(zone => seededZoneIndices.ContainsKey(zone.Code)
                && !rates.Any(rate => rate.ZoneId == zone.Id && rate.ServiceLevel == ShippingServiceLevel.Registered))
            .Select(zone =>
            {
                var index = seededZoneIndices[zone.Code];
                return new ShippingRate(
                    Guid.Parse($"60000000-0000-0000-0000-{index + 1:000000000000}"),
                    zone.Id,
                    ShippingServiceLevel.Registered,
                    85m + index * 8m,
                    30m + index * 4m,
                    30m,
                    isActive: true);
            })
            .ToArray();
        if (missingRegisteredRates.Length > 0)
        {
            await shippingRateRepository.SaveAllAsync(rates.Concat(missingRegisteredRates), cancellationToken);
        }

        var staff = await staffRepository.GetAllAsync(cancellationToken);
        if (staff.Count == 0)
        {
            var seededStaff = new List<StaffMember>();
            var branchIds = branches.Select(branch => branch.Id).ToArray();

        for (var branchIndex = 0; branchIndex < branchIds.Length; branchIndex++)
        {
            var branchNumber = branchIndex + 1;
            seededStaff.Add(CreateStaff(
                $"manager{branchNumber}@apexpost.local",
                $"Branch Manager {branchNumber}",
                StaffRole.BranchManager,
                branchIds[branchIndex],
                passwordService,
                demoPassword));

            for (var clerkIndex = 1; clerkIndex <= 2; clerkIndex++)
            {
                seededStaff.Add(CreateStaff(
                    $"clerk{branchNumber}{clerkIndex}@apexpost.local",
                    $"Counter Clerk {branchNumber}-{clerkIndex}",
                    StaffRole.CounterClerk,
                    branchIds[branchIndex],
                    passwordService,
                    demoPassword));
            }
        }

        seededStaff.Add(CreateStaff(
            "clerk-extra1@apexpost.local",
            "Counter Clerk Extra 1",
            StaffRole.CounterClerk,
            branchIds[0],
            passwordService,
            demoPassword));
        seededStaff.Add(CreateStaff(
            "clerk-extra2@apexpost.local",
            "Counter Clerk Extra 2",
            StaffRole.CounterClerk,
            branchIds[0],
            passwordService,
            demoPassword));
        seededStaff.Add(CreateStaff(
            "clerk-extra3@apexpost.local",
            "Counter Clerk Extra 3",
            StaffRole.CounterClerk,
            branchIds[0],
            passwordService,
            demoPassword));
        seededStaff.Add(CreateStaff(
            "auditor1@apexpost.local",
            "ApexPost Auditor",
            StaffRole.Auditor,
            branchIds[0],
            passwordService,
            demoPassword));
        seededStaff.Add(CreateStaff(
            "admin@apexpost.local",
            "ApexPost Administrator",
            StaffRole.Administrator,
            null,
            passwordService,
            demoPassword));

            await staffRepository.SaveAllAsync(seededStaff, cancellationToken);
            staff = seededStaff;
        }

        await SeedHistoricalTransactionsAsync(branches, staff, products, terminals, cancellationToken);
        await SeedAuditorHistoryAsync(branches, staff, cancellationToken);
    }

    private async Task SeedHistoricalTransactionsAsync(
        IReadOnlyList<Branch> branches,
        IReadOnlyList<StaffMember> staff,
        IReadOnlyList<Product> products,
        IReadOnlyList<CounterTerminal> terminals,
        CancellationToken cancellationToken)
    {
        var transactions = await transactionRepository.GetAllAsync(cancellationToken);
        var inventory = (await inventoryRepository.GetAllAsync(cancellationToken)).ToList();
        if (transactions.Count != 0 || inventory.Count != 0 || branches.Count == 0 || products.Count == 0)
        {
            return;
        }

        var rates = await shippingRateRepository.GetAllAsync(cancellationToken);
        var zones = await shippingZoneRepository.GetAllAsync(cancellationToken);
        var activeProducts = products.Where(product => product.IsActive).OrderBy(product => product.Sku).ToArray();
        if (activeProducts.Length == 0)
        {
            return;
        }

        foreach (var branch in branches)
        {
            var manager = staff.FirstOrDefault(person => person.Role == StaffRole.BranchManager && person.BranchId == branch.Id);
            var clerk = staff.FirstOrDefault(person => person.Role == StaffRole.CounterClerk && person.BranchId == branch.Id);
            if (manager is null || clerk is null)
            {
                return;
            }

            foreach (var product in activeProducts)
            {
                inventory.Add(new InventoryItem(
                    branch.Id,
                    product.Id,
                    100,
                    5,
                    [new InventoryMovement(manager.Id, 100, "Opening demo stock", DateTimeOffset.UtcNow.AddDays(-45))]));
            }
        }

        var seededTransactions = new List<CounterTransaction>(40);
        var stableBranches = branches.OrderBy(branch => branch.Code).ToArray();
        var now = DateTimeOffset.UtcNow;
        for (var index = 0; index < 40; index++)
        {
            var branch = stableBranches[index % stableBranches.Length];
            var clerk = staff.First(person => person.Role == StaffRole.CounterClerk && person.BranchId == branch.Id);
            var product = activeProducts[index % activeProducts.Length];
            var quantity = 1 + index % 3;
            var itemIndex = inventory.FindIndex(item => item.BranchId == branch.Id && item.ProductId == product.Id);
            var occurredAt = now.AddDays(-40 + index).AddHours(index % 9);
            var id = StableGuid($"historical-transaction-{index + 1:000}");
            var number = $"APT-{occurredAt:yyyyMMdd}-DEMO{index + 1:0000}";
            var manager = staff.First(person => person.Role == StaffRole.BranchManager && person.BranchId == branch.Id);
            var status = (index % 20) switch
            {
                0 => TransactionStatus.Voided,
                1 => TransactionStatus.Refunded,
                _ => TransactionStatus.Paid
            };
            var resolutionTime = status is TransactionStatus.Voided or TransactionStatus.Refunded
                ? occurredAt.AddHours(1)
                : (DateTimeOffset?)null;
            var resolutionReason = status switch
            {
                TransactionStatus.Voided => "Seeded historical void",
                TransactionStatus.Refunded => "Seeded historical refund",
                _ => null
            };
            var line = new TransactionLine(product.Id, product.Sku, product.Name, quantity, product.Price);
            Guid? shippingRateId = null;
            string? zoneName = null;
            ShippingServiceLevel? serviceLevel = null;
            decimal? weight = null;
            decimal shippingCharge = 0;

            if (index % 2 == 0 && rates.Count > 0)
            {
                var rate = rates[index % rates.Count];
                var zone = zones.FirstOrDefault(candidate => candidate.Id == rate.ZoneId);
                if (zone is not null)
                {
                    weight = 0.5m + (index % 5) * 0.25m;
                    shippingRateId = rate.Id;
                    zoneName = zone.Name;
                    serviceLevel = rate.ServiceLevel;
                    shippingCharge = rate.CalculatePrice(weight.Value);
                }
            }

            seededTransactions.Add(new CounterTransaction(
                id,
                number,
                branch.Id,
                clerk.Id,
                occurredAt,
                [line],
                shippingRateId,
                zoneName,
                serviceLevel,
                weight,
                shippingCharge,
                (index % 3) switch
                {
                    0 => PaymentMethod.Cash,
                    1 => PaymentMethod.Card,
                    _ => PaymentMethod.DigitalWallet
                },
                status: status,
                resolvedAt: resolutionTime,
                resolvedByStaffId: resolutionTime is null ? null : manager.Id,
                resolutionReason: resolutionReason,
                terminalId: terminals.First(terminal => terminal.BranchId == branch.Id && terminal.IsActive).Id));

            var changedInventory = inventory[itemIndex].ApplyChange(
                -quantity,
                inventory[itemIndex].ReorderLevel,
                $"Seeded historical sale {number}",
                clerk.Id,
                occurredAt);
            if (resolutionTime is { } resolvedAt)
            {
                changedInventory = changedInventory.ApplyChange(
                    quantity,
                    changedInventory.ReorderLevel,
                    resolutionReason!,
                    manager.Id,
                    resolvedAt);
            }
            inventory[itemIndex] = changedInventory;
        }

        await inventoryRepository.SaveAllAsync(inventory, cancellationToken);
        await transactionRepository.SaveAllAsync(seededTransactions, cancellationToken);
    }

    private async Task SeedAuditorHistoryAsync(
        IReadOnlyList<Branch> branches,
        IReadOnlyList<StaffMember> staff,
        CancellationToken cancellationToken)
    {
        var orders = (await moneyOrderRepository.GetAllAsync(cancellationToken)).ToList();
        var verifications = (await verificationRepository.GetAllAsync(cancellationToken)).ToList();
        var now = DateTimeOffset.UtcNow;
        var changedOrders = false;
        var changedVerifications = false;

        foreach (var (branch, branchIndex) in branches.Select((value, index) => (value, index)))
        {
            var clerk = staff.FirstOrDefault(person => person.Role == StaffRole.CounterClerk && person.BranchId == branch.Id);
            var manager = staff.FirstOrDefault(person => person.Role == StaffRole.BranchManager && person.BranchId == branch.Id);
            if (clerk is null || manager is null)
                continue;

            var verificationId = StableGuid($"historical-verification-{branch.Code}");
            var verifiedOrderId = StableGuid($"historical-verified-money-order-{branch.Code}");
            var verifiedAmount = Math.Max(100m, moneyOrderPolicy.IdentityVerificationThreshold + 1m);
            var occurredAt = now.AddDays(-10).AddHours(branchIndex);
            var maskedIdentifier = "****1234";

            if (verifications.All(record => record.Id != verificationId))
            {
                verifications.Add(new IdentityVerificationRecord(
                    verificationId,
                    branch.Id,
                    clerk.Id,
                    occurredAt,
                    IdentityDocumentType.NationalId,
                    maskedIdentifier,
                    verifiedAmount,
                    IdentityVerificationStatus.Verified,
                    $"seed-{branch.Code.ToLowerInvariant()}"));
                changedVerifications = true;
            }

            if (orders.All(order => order.Id != verifiedOrderId))
            {
                var refund = branchIndex == 0;
                orders.Add(new MoneyOrder(
                    verifiedOrderId,
                    $"APM-{occurredAt:yyyyMMdd}-{verifiedOrderId.ToString("N")[..8].ToUpperInvariant()}",
                    branch.Id,
                    clerk.Id,
                    occurredAt,
                    $"Demo Sender {branch.Code}",
                    $"Demo Recipient {branch.Code}",
                    verifiedAmount,
                    moneyOrderPolicy.FeeAmount,
                    IdentityVerificationStatus.Verified,
                    verificationId,
                    IdentityDocumentType.NationalId,
                    maskedIdentifier,
                    refund ? MoneyOrderStatus.Refunded : MoneyOrderStatus.Issued,
                    refund ? occurredAt.AddHours(1) : null,
                    refund ? manager.Id : null,
                    refund ? "Seeded historical refund" : null));
                changedOrders = true;
            }

            var standardOrderId = StableGuid($"historical-standard-money-order-{branch.Code}");
            if (moneyOrderPolicy.IdentityVerificationThreshold > 0 &&
                orders.All(order => order.Id != standardOrderId))
            {
                var standardAmount = moneyOrderPolicy.IdentityVerificationThreshold;
                var standardOccurredAt = occurredAt.AddDays(-2);
                orders.Add(new MoneyOrder(
                    standardOrderId,
                    $"APM-{standardOccurredAt:yyyyMMdd}-{standardOrderId.ToString("N")[..8].ToUpperInvariant()}",
                    branch.Id,
                    clerk.Id,
                    standardOccurredAt,
                    $"Demo Sender {branch.Code}",
                    $"Demo Recipient {branch.Code}",
                    standardAmount,
                    moneyOrderPolicy.FeeAmount,
                    IdentityVerificationStatus.NotRequired,
                    null,
                    null,
                    null));
                changedOrders = true;
            }
        }

        if (changedVerifications)
            await verificationRepository.SaveAllAsync(verifications, cancellationToken);
        if (changedOrders)
            await moneyOrderRepository.SaveAllAsync(orders, cancellationToken);
    }

    private static Guid StableGuid(string value)
    {
        var hash = System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(value));
        return new Guid(hash.AsSpan(0, 16));
    }

    private static StaffMember CreateStaff(
        string email,
        string fullName,
        StaffRole role,
        Guid? branchId,
        IStaffPasswordService passwordService,
        string password)
    {
        var staffId = GuidFromEmail(email);
        return new StaffMember(
            staffId,
            email,
            fullName,
            role,
            branchId,
            isActive: true,
            passwordService.Hash(password));
    }

    private static Guid GuidFromEmail(string email)
    {
        var bytes = System.Security.Cryptography.SHA256.HashData(
            System.Text.Encoding.UTF8.GetBytes(email));
        return new Guid(bytes.AsSpan(0, 16));
    }
}

